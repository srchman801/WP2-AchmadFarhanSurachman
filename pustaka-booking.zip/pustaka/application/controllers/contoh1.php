<?php
class contoh1 extends CI_Controller
{
    public function index()
    {
        echo "<h1>PERKENALKAN</h1>";
        echo "Nama Saya Achmad Farhan Surachman
              Saya tinggal di jakarta Pusat
              olahraga yg disukai voli";
    }
}
